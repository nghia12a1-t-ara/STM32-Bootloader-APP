import re

class ParseHexFile:
    def __init__(self, path):
        self.path = path

    def ParseData(self, lineContent, byteCountDec):
        if int(byteCountDec) > 0:
            EndDataField = 8 + (byteCountDec * 2)
            Data = lineContent[8:EndDataField]
        return Data        

    def ParseFile(self):
        with open(self.path, 'r') as HexFile:
            HexText = HexFile.read()
        ListLine = re.findall(r':(\w+)', HexText)
        numLine = len(ListLine)

        BASE_ADDRESS_DEC = 0
        DataList = []
        
        for line in range(numLine):
            tempDict = {}
            
            lineContent = ListLine[line]

            # Get byte Count from Hex Line - 2 characters
            byteCountHex = lineContent[0:2]
            byteCountDec = int(byteCountHex, 16)

            # Get Address - 4 characters
            offsetAddr = lineContent[2:6]
            
            # Get Record Types - 2 characters
            RecordTypeHex = lineContent[6:8]
            RecordTypeDec = int(RecordTypeHex, 16)

            if RecordTypeDec == 0:
                # Data
                tempData = self.ParseData(lineContent, byteCountDec)

                # Calculate Address
                BASE_ADDRESS_DEC = int(BASE_ADDRESS, 16)
                offsetAddr_DEC = int(offsetAddr, 16)
                Address_DEC = BASE_ADDRESS_DEC + offsetAddr_DEC
                tempAddress = hex(Address_DEC)

                ### Save Address and Data
                tempDict = ({tempAddress: tempData})
                DataList.append(tempDict)
                
            elif RecordTypeDec == 1:
                # End of File
                break
            elif RecordTypeDec == 4:
                # Base Address
                BASE_ADDRESS = self.ParseData(lineContent, byteCountDec)

        return DataList

### Example ### 
Object1 = ParseHexFile("C:\\Users\\NghiaNV16\\Desktop\\test.hex")
Object1.ParseFile() 
